package cola_test

import (
	ColaEnlazada "tdas/cola"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestColaVAcia(t *testing.T) {
	cola := ColaEnlazada.CrearColaEnlazada[int]()
	require.True(t, cola.EstaVacia())
	require.Panics(t, func() { cola.Desencolar() })
	require.Panics(t, func() { cola.VerPrimero() })
}

func TestEncolarYDesencolarConUnElemento(t *testing.T) {
	cola := ColaEnlazada.CrearColaEnlazada[int]()
	cola.Encolar(4)
	require.False(t, cola.EstaVacia())
	require.Equal(t, 4, cola.Desencolar())
	require.True(t, cola.EstaVacia())
}

func TestEncolarYDesencolarVarios(t *testing.T) {
	cola := ColaEnlazada.CrearColaEnlazada[int]()
	elementos := []int{1, 2, 3, 4, 5}
	for _, elem := range elementos {
		cola.Encolar(elem)
		require.Equal(t, 1, cola.VerPrimero())
	}
	require.Equal(t, 1, cola.Desencolar())
	cola.Encolar(6)
	for i := 1; i < len(elementos)-1; i++ {
		cola.Desencolar()
		require.Equal(t, elementos[i+1], cola.VerPrimero())
	}
	require.Equal(t, 5, cola.Desencolar())
	require.Equal(t, 6, cola.Desencolar())
	require.True(t, cola.EstaVacia())
	require.Panics(t, func() { cola.Desencolar() })
	require.Panics(t, func() { cola.VerPrimero() })
}

func TestVolumen(t *testing.T) {
	cola := ColaEnlazada.CrearColaEnlazada[int]()
	volumen := make([]int, 10000)
	for indice := range volumen {
		cola.Encolar(indice)
	}
	for i := 1; i < len(volumen); i++ {
		cola.Desencolar()
		require.Equal(t, i, cola.VerPrimero())
	}
	cola.Desencolar()
	require.True(t, cola.EstaVacia())
	require.Panics(t, func() { cola.Desencolar() })
	require.Panics(t, func() { cola.VerPrimero() })
}

func TestDistintoTipo(t *testing.T) {
	cola := ColaEnlazada.CrearColaEnlazada[string]()
	require.True(t, cola.EstaVacia())
	require.Panics(t, func() { cola.Desencolar() })
	require.Panics(t, func() { cola.VerPrimero() })
	cola.Encolar("hola")
	cola.Encolar("mundo")
	require.False(t, cola.EstaVacia())
	require.Equal(t, "hola", cola.VerPrimero())
	require.Equal(t, "hola", cola.Desencolar())
	require.Equal(t, "mundo", cola.VerPrimero())
	require.Equal(t, "mundo", cola.Desencolar())
	require.True(t, cola.EstaVacia())
}
