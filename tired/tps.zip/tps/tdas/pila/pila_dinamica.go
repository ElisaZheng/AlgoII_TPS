package pila

/* Definición del struct pila proporcionado por la cátedra. */

const capacidadInicial int = 10

type pilaDinamica[T any] struct {
	datos    []T
	cantidad int
}

func CrearPilaDinamica[T any]() Pila[T] {
	arreglo := make([]T, capacidadInicial)
	return &pilaDinamica[T]{datos: arreglo, cantidad: 0}
}

func (p *pilaDinamica[T]) Apilar(dato T) {
	p.datos[p.cantidad] = dato
	p.cantidad++
	if p.cantidad == len(p.datos) {
		p.datos = p.redimension(len(p.datos)*2, p.datos)
	}
}

func (p *pilaDinamica[T]) Desapilar() T {
	if p.EstaVacia() {
		panic("La pila esta vacia")
	}
	p.cantidad--
	elemento := p.datos[p.cantidad]
	if p.cantidad < len(p.datos)/4 && p.cantidad/2 >= capacidadInicial {
		p.datos = p.redimension(len(p.datos)/2, p.datos)
	}
	return elemento
}

func (p *pilaDinamica[T]) VerTope() T {
	if p.EstaVacia() {
		panic("La pila esta vacia")
	}
	return p.datos[p.cantidad-1]
}

func (p *pilaDinamica[T]) EstaVacia() bool {
	return p.cantidad == 0
}

func (p *pilaDinamica[T]) redimension(tamano int, arreglo []T) []T {
	nuevosDatos := make([]T, tamano)
	copy(nuevosDatos, arreglo)
	return nuevosDatos
}
