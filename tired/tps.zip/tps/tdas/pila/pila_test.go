package pila_test

import (
	TDAPila "tdas/pila"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestPilaVacia(t *testing.T) {
	pila := TDAPila.CrearPilaDinamica[int]()
	require.True(t, pila.EstaVacia())
	require.Panics(t, func() { pila.Desapilar() })
	require.Panics(t, func() { pila.VerTope() })

}

func TestApilar(t *testing.T) {
	pila := TDAPila.CrearPilaDinamica[int]()
	vect := []int{1, 2, 3, 4, 5}
	for _, elem := range vect {
		pila.Apilar((elem))
		require.Equal(t, elem, pila.VerTope())
	}
}

func TestDesapilar(t *testing.T) {
	pila := TDAPila.CrearPilaDinamica[int]()
	vect := []int{1, 2, 3, 4, 5}
	for _, elem := range vect {
		pila.Apilar((elem))
	}
	for i := 1; i < len(vect); i++ {
		pila.Desapilar()
		require.Equal(t, vect[len(vect)-i-1], pila.VerTope())
	}
	pila.Desapilar()
	require.True(t, pila.EstaVacia())
}

func TestVolumen(t *testing.T) {
	pila := TDAPila.CrearPilaDinamica[int]()
	volumen := make([]int, 1000)
	for indice := range volumen {
		pila.Apilar(indice)
		require.Equal(t, indice, pila.VerTope())
	}
	for i := 1; i < len(volumen); i++ {
		pila.Desapilar()
		require.Equal(t, len(volumen)-i-1, pila.VerTope())
	}
}

func TestDistintoTipo(t *testing.T) {
	pila := TDAPila.CrearPilaDinamica[string]()
	require.True(t, pila.EstaVacia())
	require.Panics(t, func() { pila.VerTope() })
	require.Panics(t, func() { pila.Desapilar() })
	pila.Apilar("hola")
	require.False(t, pila.EstaVacia())
	require.Equal(t, "hola", pila.VerTope())
	require.Equal(t, "hola", pila.Desapilar())
	require.True(t, pila.EstaVacia())
}
