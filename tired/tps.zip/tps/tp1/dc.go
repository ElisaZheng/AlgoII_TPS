package main

import (
	"bufio"
	"errors"
	"fmt"
	"os"
	"strconv"
	"strings"
	"tdas/pila"
	"tp1/operacion"
)

const mensajeError string = "ERROR"

func esNum(valor string) (int, error) {
	num, err := strconv.Atoi(valor)
	if err == nil {
		return num, nil
	}
	return 0, errors.New(mensajeError)
}

func esOperador(valor string) bool {
	operadores := "+ - / log sqrt ^ ? *"
	return strings.Contains(operadores, valor)
}

func vaciarPilaYError(p pila.Pila[int]) {
	for !p.EstaVacia() {
		p.Desapilar()
	}
	fmt.Println(mensajeError)
}

func main() {
	entrada := bufio.NewScanner(os.Stdin)
	for entrada.Scan() {
		if entrada.Text() == "" {
			break
		}
		linea := strings.Split(entrada.Text(), " ")
		pila := pila.CrearPilaDinamica[int]()
		for _, elem := range linea {
			num, error := esNum(elem)
			if error == nil {
				pila.Apilar(num)
			} else if esOperador(elem) {
				num, err := operacion.CalculadoraEnNotacionPosfija(pila, elem)
				if err == nil {
					pila.Apilar(num)
				} else {
					vaciarPilaYError(pila)
					break
				}
			} else {
				vaciarPilaYError(pila)
				break
			}
		}
		if !pila.EstaVacia() {
			resultado := pila.Desapilar()
			if pila.EstaVacia() {
				fmt.Println(resultado)
			} else {
				fmt.Println(mensajeError)
			}

		}
	}
}
