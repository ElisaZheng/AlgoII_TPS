package operacion

import (
	"errors"
	"math"
	"tdas/pila"
)

const (
	err          string = "ERROR"
	mulplicacion string = "*"
	suma         string = "+"
	resta        string = "-"
	division     string = "/"
	logaritmo    string = "log"
	raiz         string = "sqrt"
	ternario     string = "?"
	exponencia   string = "^"
)

func CalculadoraEnNotacionPosfija(p pila.Pila[int], operador string) (int, error) {
	var (
		resul = 0
		error = errors.New(err)
	)
	numeros, err := calcularCantidadNumerosNecesitados(p, operador)
	if err != nil {
		return resul, error
	}
	switch operador {
	case suma:
		resul, error = calcularSuma(numeros)
	case resta:
		resul, error = calcularResta(numeros)
	case division:
		resul, error = calcularDivision(numeros)
	case mulplicacion:
		resul, error = calcularMultiplicacion(numeros)
	case logaritmo:
		resul, error = calcularLogaritmos(numeros)
	case exponencia:
		resul, error = calcularExponencia(numeros)
	case ternario:
		resul, error = calcularTernario(numeros)
	case raiz:
		resul, error = calcularRaizCuadrada(numeros)
	}
	return resul, error
}

func calcularCantidadNumerosNecesitados(p pila.Pila[int], operador string) ([]int, error) {
	error := errors.New(err)
	numeros := make([]int, 0)
	cantidadDeNum := 0
	if operador == ternario {
		for !p.EstaVacia() {
			if cantidadDeNum == 3 {
				break
			}
			numeros = append(numeros, p.Desapilar())
			cantidadDeNum++
		}
		if cantidadDeNum < 3 {
			return numeros, error
		}
	} else if operador == raiz {
		for !p.EstaVacia() {
			if cantidadDeNum == 1 {
				break
			}
			numeros = append(numeros, p.Desapilar())
			cantidadDeNum++
		}
		if cantidadDeNum < 1 {
			return numeros, error
		}
	} else {
		for !p.EstaVacia() {
			if cantidadDeNum == 2 {
				break
			}
			numeros = append(numeros, p.Desapilar())
			cantidadDeNum++
		}
		if cantidadDeNum < 2 {
			return numeros, error
		}
	}
	return numeros, nil
}

func calcularSuma(numeros []int) (int, error) {
	resultado := numeros[0] + numeros[1]
	return resultado, nil
}

func calcularResta(numeros []int) (int, error) {
	resultado := numeros[1] - numeros[0]
	return resultado, nil
}

func calcularMultiplicacion(numeros []int) (int, error) {
	resultado := numeros[1] * numeros[0]
	return resultado, nil
}

func calcularDivision(numeros []int) (int, error) {
	if numeros[0] == 0 {
		return 0, errors.New(err)
	}
	resultado := numeros[1] / numeros[0]
	return resultado, nil
}

func calcularExponencia(numeros []int) (int, error) {
	if numeros[0] < 0 {
		return 0, errors.New(err)
	}
	resultado := int(math.Pow(float64(numeros[1]), float64(numeros[0])))
	return resultado, nil
}

func calcularRaizCuadrada(numeros []int) (int, error) {
	if numeros[0] < 0 {
		return 0, errors.New(err)
	}
	resultado := int(math.Sqrt(float64(numeros[0])))
	return resultado, nil
}

func calcularLogaritmos(numeros []int) (int, error) {
	if numeros[0] < 2 {
		return 0, errors.New(err)
	}
	resultado := int(math.Log(float64(numeros[1])) / math.Log(float64(numeros[0])))
	return resultado, nil
}

func calcularTernario(numeros []int) (int, error) {
	resultado := 0
	if numeros[2] == 0 {
		resultado = numeros[0]
	} else {
		resultado = numeros[1]
	}
	return resultado, nil
}
